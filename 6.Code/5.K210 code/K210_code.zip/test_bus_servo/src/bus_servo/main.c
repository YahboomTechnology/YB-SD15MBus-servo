/**
* @par  Copyright (C): 2016-2022, Shenzhen Yahboom Tech
* @file         main.c
* @author       Gengyue
* @version      V1.0
* @date         2020.12.15
* @brief        串口控制总线舵机实验
* @details      
* @par History  见如下说明
*                 
* version:	V1.0: 开机设置舵机ID=1，然后控制舵机来回转动，
*                 并读取舵机运行前的位置并打印到typeC串口。
*/
#include <string.h>
#include "pin_config.h"
#include "bsp.h"
#include "sysctl.h"
#include "bus_servo.h"
#include "stdio.h"

void hardware_init(void)
{
    /* USB串口 */
    fpioa_set_function(PIN_UART_USB_RX, FUNC_UART_USB_RX);
    fpioa_set_function(PIN_UART_USB_TX, FUNC_UART_USB_TX);

    /* WIFI模块串口 */
    fpioa_set_function(PIN_UART_WIFI_RX, FUNC_UART_WIFI_RX);
    fpioa_set_function(PIN_UART_WIFI_TX, FUNC_UART_WIFI_TX);

}

int core1_function(void *ctx)
{
    uint64_t core = current_coreid();
    printf("Core %ld Hello world\n", core);
    while (1)
    {
        bus_servo_control(0xfe, 3500, 1500);
        sleep(2);
        bus_servo_read(0x01);
        msleep(500);
        bus_servo_control(0xfe, 900, 1500);
        sleep(2);
        bus_servo_read(0x01);
        msleep(500);
    }
}


int main(void)
{
    hardware_init();
    // 初始化USB串口，设置波特率为115200
    uart_init(UART_USB_NUM);
    uart_configure(UART_USB_NUM, 115200, UART_BITWIDTH_8BIT, UART_STOP_1, UART_PARITY_NONE);

    /* 初始化WiFi模块的串口 */
    uart_init(UART_WIFI_NUM);
    uart_configure(UART_WIFI_NUM, 115200, UART_BITWIDTH_8BIT, UART_STOP_1, UART_PARITY_NONE);

    /* 开机发送hello yahboom! */
    char *hello = {"hello yahboom!\n"};
    uart_send_data(UART_USB_NUM, hello, strlen(hello));

    bus_servo_set_id(1);
    sleep(1);
    register_core1(core1_function, NULL);
    
    /* 接收和发送缓存的数据 */
    uint8_t recv = 0, send = 0;

    while (1)
    {
        /* 接收WIFI模块的信息 */
        while(uart_receive_data(UART_WIFI_NUM, &recv, 1))
        {
            /* 发送接收到的数据到USB串口显示 */
            // uart_send_data(UART_USB_NUM, &recv, 1);
            
            bus_servo_uart_recv(recv);
        }

        /* 接收串口的信息，并发送给WiFi模块 */
        // if(uart_receive_data(UART_USB_NUM, &send, 1))
        // {
        //     uart_send_data(UART_WIFI_NUM, &send, 1);
        // }

        if(bus_servo_get_recvflag())
        {
            bus_servo_clear_recvflag();
            int value1 = bus_servo_get_value();
            char cmd[20];
            sprintf(cmd, "value is:%d\r\n", value1);
            uart_send_data(UART_USB_NUM, cmd, strlen(cmd));
        }
    }
    return 0;
}
